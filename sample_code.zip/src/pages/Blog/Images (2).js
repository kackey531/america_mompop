const Images = [
  {
    url: "dj-johnson-tgoO5H81nrU-unsplash.jpg",
    title: "Buitenreclame",
    desc: "",
    linkTo: "/blog/buitenreclame",
  },
  {
    url: "blogpost3.jpg",
    title: "De kracht van papier",
    desc: "",
    linkTo: "/blog/kracht-van-papier",
  },
  {
    url: "jon-tyson-t2cp_cWMo3o-unsplash.jpg",
    title: "Motion/animatie",
    desc: "",
    linkTo: "/blog/motion-animatie",
  },
  {
    url: "boxed-water-is-better-7mr6Yx-8WLc-unsplash.jpg",
    title: "Verpakkingen",
    desc: "",
    linkTo: "/blog/verpakkingen",
  },
  {
    url: "jakob-owens-CiUR8zISX60-unsplash.jpg",
    title: "Waarom video",
    desc: "",
    linkTo: "/blog/waarom-video",
  },
  {
    url: "Shipwreckedbranding.jpg",
    title: "WAAROM EEN CONSISTENTE HUISSTIJL BELANGRIJK IS",
    desc: "",
    linkTo: "/blog/belang-consistente-huisstijl",
  },
  {
    url: "worktable.jpg",
    title: "Sterk logo, sterk merk",
    desc: "",
    linkTo: "/blog/sterk-logo",
  },
  {
    url: "markus-winkler-afW1hht0NSs-unsplash.jpg",
    title: "Google Mijn Bedrijf",
    desc: "",
    linkTo: "/blog/google-mijn-bedrijf",
  },
];

export default Images;
