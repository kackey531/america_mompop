const Images = [
  {
    url: "lhspreview.jpg",
    title: "LITTLE HANDMADE STORIES, AVELGEM",
    desc: "",
    linkTo: "/cases/little-handmade-stories",
  },
  {
    url: "debaveyepreview.jpg",
    title: "DE BAVEYE INTERIEUR, OUTRIJVE",
    desc: "",
    linkTo: "/cases/de-baveye-interieur",
  },
  {
    url: "hhjpreview2.jpg",
    title: "HAPPY HANDMADE JEWELS, OUTRIJVE",
    desc: "",
    linkTo: "/cases/happy-handmade-jewels",
  },
  {
    url: "keurslagerpreview2.jpg",
    title: "KEURSLAGER CRUL, MOEN",
    desc: "",
    linkTo: "/cases/keurslager-crul",
  },
  {
    url: "ebopreview.jpg",
    title: "EBO, INGOOIGEM",
    desc: "",
    linkTo: "/cases/energie-bouw-ovaere",
  },
  {
    url: "portfolio1.jpg",
    title: "CAFETARIA MICHELSBERG, SPIERE-HELKIJN",
    desc: "",
    linkTo: "/cases/cafetaria-michelsberg",
  },
  {
    url: "portfolio2.jpg",
    title: "PITTA MELITA, AVELGEM",
    desc: "",
    linkTo: "/cases/pitta-melita",
  },
  {
    url: "portfolio3.jpg",
    title: "MALAMUTE MATTERS, GROOT-BRITTANNIË",
    desc: "",
    linkTo: "/cases/malamute-matters",
  },
  {
    url: "portfolio4.jpg",
    title: "EECKHOUT - WOODLINE, OOSTROZEBEKE",
    desc: "",
    linkTo: "/cases/eeckhout-woodline",
  },

  {
    url: "portfolio5.jpg",
    title: "SLAGERIJ CANNAERT, ANZEGEM",
    desc: "",
    linkTo: "/cases/slagerij-cannaert",
  },
  {
    url: "portfolio6.jpg",
    title: "HET LIJSTERNEST, INGOOIGEM",
    desc: "",
    linkTo: "/cases/het-lijsternest",
  },
  {
    url: "portfolio7.jpg",
    title: "BLACK - DIRK BRACKE",
    desc: "",
    linkTo: "/cases/black",
  },
  {
    url: "portfolio8.png",
    title: "MAGAZINE CROSSMEDIA",
    desc: "",
    linkTo: "/cases/magazine-crossmedia",
  },
];

export default Images;
