const cases = [
  {
    url: "ec.jpg",
    title: "Edgard & Cooper",
    desc:
      "Edgard & Cooper is een van onze vaste klanten, een snelgroeiende start-up die gezond honden- en katteneten maakt.",
    linkTo: "/graveyard/edgard-cooper",
  },
  {
    url: "mig.jpg",
    title: "MIG Motors",
    desc:
      "MIG Motors is een officiële dealer van Audi, Volkswagen, Seat en Škoda in regio Gent. Ze onderscheiden zich door middel van hun 3 pijlers: productaanbod, dienstverlening en imago, maar daar vertellen ze je graag meer over als je even langsgaat voor een nieuwe (tweedehands)wagen.",
    linkTo: "/graveyard/mig-motors",
  },
];

export default cases;
